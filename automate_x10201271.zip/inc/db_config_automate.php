<?php
   /** 
	* Contains the configuration details for the database connection, defining them as named constants.
	*	- user
	*	- password 
	*	- db name
	*	- db server 
	*/
	define('user', "root");
	define('password', ""); 
	define('database', "automate");
	define('server', "localhost");
?>