<html>
	<head>
		<?php echo "<title>Automate - $pagetitle</title>"; ?>
		<link rel="stylesheet" type="text/css" href="http://localhost/automate/inc/style.css">
		<script type="text/javascript" src="http://localhost/automate/resources/js/jquery.js"></script>
	</head>
	
	<body>
		<div id="wrapper">
		
			<div id="banner">
				<img src="http://localhost/automate/images/banner.jpg" />
			</div>
			
			<div id="content" align="center">
				<p class="navigation">| <a href="http://localhost/automate/home">Home</a> | <a href="http://localhost/automate/assets">Assets</a> | <a href="http://localhost/automate/config">Config</a> | <a href="http://localhost/automate/import">Import</a> | <a href="http://localhost/automate/admin">Admin</a> | <a href="http://localhost/automate/logout">Logout</a> |</p>